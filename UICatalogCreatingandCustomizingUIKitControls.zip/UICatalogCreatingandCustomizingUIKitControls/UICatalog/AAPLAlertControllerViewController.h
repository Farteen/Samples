/*
    Copyright (C) 2014 Apple Inc. All Rights Reserved.
    See LICENSE.txt for this sample’s licensing information
    
    Abstract:
    
                The view controller that demonstrates how to use UIAlertController.
            
*/

@import UIKit;

@interface AAPLAlertControllerViewController : UITableViewController

@end

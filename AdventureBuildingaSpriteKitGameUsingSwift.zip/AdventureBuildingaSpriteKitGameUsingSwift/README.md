Adventure - Swift
=================

This project is a conversion of the original Adventure sample rewritten from the ground up in Swift.

For more information on the original Objective-C version, see [Code:Explained Adventure](https://developer.apple.com/library/ios/documentation/GraphicsAnimation/Conceptual/CodeExplainedAdventure/).

Known Issues
------------

* Multiplayer support is not yet included.
* Game controllers are not yet supported.
